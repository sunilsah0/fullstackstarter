import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';
import authRouter from './routes/auth.js';
import userRouter from './routes/user.js';

const app = express();
const prisma = new PrismaClient();

const PORT = Number(process.env.PORT || 4000);
const allowed = [
  'http://localhost:3000', // Next.js web
  'http://127.0.0.1:3000',
  'http://localhost:19006', // Expo web preview
  'http://localhost:19000'
];

app.use(cors({ origin: (origin, cb) => cb(null, true), credentials: true }));
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', (_req, res) => res.json({ ok: true }));

// Routes
app.use('/auth', authRouter);
app.use('/', userRouter);

app.use((err: any, _req: any, res: any, _next: any) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});
