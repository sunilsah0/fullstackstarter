'use client';
import { useState } from 'react';
import { createApi, endpoints } from '@app/shared';

const api = createApi({ baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000' });

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState<string | null>(null);

  const onSubmit = async (e: any) => {
    e.preventDefault();
    setMsg(null);
    try {
      const data = await endpoints.login(api, { email, password });
      localStorage.setItem('token', data.token);
      setMsg('Logged in! Go to Dashboard.');
    } catch (e: any) {
      setMsg(e?.response?.data?.error ?? 'Login failed');
    }
  };

  return (
    <div className="card">
      <h1 className="text-xl font-semibold">Login</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="input" placeholder="Email" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
        <button className="btn" type="submit">Login</button>
      </form>
      {msg && <p>{msg}</p>}
    </div>
  );
}
