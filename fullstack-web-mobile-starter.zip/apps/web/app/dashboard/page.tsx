'use client';
import { useEffect, useState } from 'react';
import { createApi, endpoints } from '@app/shared';

export default function Dashboard() {
  const [me, setMe] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const api = createApi({ 
    baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
    getToken: () => typeof window !== 'undefined' ? localStorage.getItem('token') : null
  });

  useEffect(() => {
    endpoints.me(api)
      .then((data) => setMe(data.user))
      .catch((e) => setError(e?.response?.data?.error ?? 'Not authenticated'));
  }, []);

  if (error) return <div className="card"><p>{error}</p></div>;
  if (!me) return <div className="card"><p>Loading...</p></div>;

  return (
    <div className="card">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <pre className="whitespace-pre-wrap">{JSON.stringify(me, null, 2)}</pre>
    </div>
  );
}
