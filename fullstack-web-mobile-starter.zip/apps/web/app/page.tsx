import Link from 'next/link';

export default function Home() {
  return (
    <div className="card">
      <h1 className="text-2xl font-bold">Fullstack Starter</h1>
      <p>Next.js + Express + Prisma + Expo</p>
      <div className="space-x-3">
        <Link className="link" href="/register">Register</Link>
        <Link className="link" href="/login">Login</Link>
        <Link className="link" href="/dashboard">Dashboard</Link>
      </div>
    </div>
  );
}
