import React, { useState, useEffect } from 'react';
import { SafeAreaView, View, Text, TextInput, Button, Alert } from 'react-native';
import * as SecureStore from 'expo-secure-store';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000';

export default function App() {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [me, setMe] = useState(null);

  async function login() {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) return Alert.alert('Error', data.error || 'Login failed');
    await SecureStore.setItemAsync('token', data.token);
    setEmail('');
    setPassword('');
    fetchMe();
  }

  async function register() {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name })
    });
    const data = await res.json();
    if (!res.ok) return Alert.alert('Error', data.error || 'Register failed');
    Alert.alert('Success', 'Registered! You can now log in.');
    setMode('login');
  }

  async function fetchMe() {
    const token = await SecureStore.getItemAsync('token');
    if (!token) return;
    const res = await fetch(`${API_URL}/me`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    if (res.ok) setMe(data.user);
    else setMe(null);
  }

  useEffect(() => { fetchMe(); }, []);

  return (
    <SafeAreaView style={{ flex: 1, padding: 24 }}>
      <Text style={{ fontSize: 24, fontWeight: '600', marginBottom: 12 }}>Mobile App</Text>

      {me ? (
        <View>
          <Text>You are logged in as:</Text>
          <Text selectable>{JSON.stringify(me, null, 2)}</Text>
          <Button title="Logout" onPress={async ()=>{ await SecureStore.deleteItemAsync('token'); setMe(null); }} />
        </View>
      ) : (
        <View>
          {mode === 'register' && (
            <TextInput placeholder="Name" value={name} onChangeText={setName} style={{ borderWidth: 1, padding: 10, marginBottom: 8 }} />
          )}
          <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={{ borderWidth: 1, padding: 10, marginBottom: 8 }} autoCapitalize="none" />
          <TextInput placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry style={{ borderWidth: 1, padding: 10, marginBottom: 8 }} />
          {mode === 'login' ? (
            <Button title="Login" onPress={login} />
          ) : (
            <Button title="Register" onPress={register} />
          )}
          <View style={{ height: 8 }} />
          <Button title={mode === 'login' ? "Go to Register" : "Go to Login"} onPress={()=>setMode(mode==='login'?'register':'login')} />
        </View>
      )}
    </SafeAreaView>
  );
}
