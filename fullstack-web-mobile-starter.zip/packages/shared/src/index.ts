import axios, { AxiosInstance } from 'axios';

export type CreateApiOptions = {
  baseURL: string;
  getToken?: () => string | null;
};

export function createApi({ baseURL, getToken }: CreateApiOptions): AxiosInstance {
  const client = axios.create({ baseURL });
  client.interceptors.request.use((config) => {
    const token = getToken?.();
    if (token) config.headers['Authorization'] = `Bearer ${token}`;
    return config;
  });
  return client;
}

// Simple helper calls
export const endpoints = {
  register: (client: AxiosInstance, data: { email: string; password: string; name?: string }) =>
    client.post('/auth/register', data).then(r => r.data),
  login: (client: AxiosInstance, data: { email: string; password: string }) =>
    client.post('/auth/login', data).then(r => r.data),
  me: (client: AxiosInstance) => client.get('/me').then(r => r.data)
};
